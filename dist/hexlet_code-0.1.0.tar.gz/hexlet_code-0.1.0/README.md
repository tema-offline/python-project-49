### Hexlet tests and linter status:
[![Actions Status](https://github.com/tema-offline/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tema-offline/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/0489a6881d0f46403e7c/maintainability)](https://codeclimate.com/github/tema-offline/python-project-49/maintainability)